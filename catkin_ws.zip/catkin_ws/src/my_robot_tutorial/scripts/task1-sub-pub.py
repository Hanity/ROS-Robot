#!/usr/bin/env python3
import rospy

from std_msgs.msg import String, Float32

def callback_function(data2):
    #print("Msg received: " + str(data2))
    pub = rospy.Publisher('speed',Float32, queue_size=10)

    radius = 1
    speed = radius*3.14*(data2.data)
    #speed = 1.2
    pub.publish(speed)

def sub_function():
    rospy.init_node("node2")
    pub = rospy.Subscriber('rpm',Float32, callback_function)


if __name__ == "__main__":
    sub_function()
    rospy.spin()
