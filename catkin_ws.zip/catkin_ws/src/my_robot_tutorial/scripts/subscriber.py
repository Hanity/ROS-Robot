import rospy

from std_msgs.msg import String

def callback_function(data):
    print("Msg received: " + str(data))

def sub_function():
    rospy.init_node("sub_function_node")
    pub = rospy.Subscriber('pub_msg',String, callback_function)



if __name__ == "__main__":
    sub_function()
    rospy.spin()
