#!/usr/bin/env python3

import rospy

from std_msgs.msg import Float32, String

def pub_function():
    rospy.init_node('node1')
    pub = rospy.Publisher('rpm',Float32, queue_size=10)
    rate = rospy.Rate(5)
    while not rospy.is_shutdown():
        rpm = rospy.get_param("/wheel_radius")
        pub.publish(rpm)
        rate.sleep()

if __name__ == "__main__":
    try:
        pub_function()
    except rospy.ROSInterruptException:
        pass
